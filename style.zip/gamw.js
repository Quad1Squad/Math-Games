const gameForm = document.getElementById('game-form');
const guessInput = document.getElementById('guess');
const message = document.getElementById('message');
const hints = document.getElementById('hints');

let answer = Math.floor(Math.random() * 20) + 1;
let factors = [];

for (let i = 1; i <= answer; i++) {
  if (answer % i === 0) {
    factors.push(i);
  }
}

hints.innerHTML = `Hints:<br>
                    ${
                      answer > 9
                        ? 'Number of digits in the number is 2.<br>'
                        : 'The number is a single digit number.<br>'
                    }
                    The factors of the number are:<br>
                    ${factors.join(', ')}<br>`;

gameForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const guess = parseInt(guessInput.value);
  if (guess === answer) {
    message.textContent = 'You have guessed it correctly!!!';
  } else {
    message.textContent = 'Wrong, try again.';
  }
});
